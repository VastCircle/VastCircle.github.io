---

title: "Big_soc_路径查找"
slug: "Big_soc_路径查找"
description: 
date: "2024-10-30T16:25:09+08:00"
lastmod: "2024-10-30T16:25:09+08:00"
image: 
math: 
license: 
hidden: false
draft: false 
categories: ["rocket-chip"]
tags: [""]

---
## 路径查找

### Bootrom ClockSinkDomain_1.sv 

![](image-20241030164859345.png)

### ClockSinkDomain_1 bootROMDomainWrapper DigitalTop.sv

![](image-20241030164741290.png)

### PeripheryBus_1 subsystem_cbus  DigitalTop.sv

![](image-20241030165640444.png)

####  TLInterconnectCoupler_33 coupler_to_bootrom TLInterconnectCoupler_33.sv

![](image-20241031010752745.png)

#### TLXbar_5 out_xbar  PeripheryBus_1.sv

![](image-20241030185219084.png)

![](image-20241030195740788.png)

#### TLInterconnectCoupler coupler_to_l2_ctrl peripherybus_1.sv  

![](image-20241031111411200.png)

#####  TLFragmenter_2 fragmenter TLInterconnectCoupler.sv

![](image-20241031110902027.png)

#####  TLBuffer_6 buffer  TLInterconnectCoupler.sv

![](image-20241031111054483.png)

#### TLInterconnectCoupler coupler_to_l2_ctrl peripherybus_1.sv  

![](image-20241031111459980.png)

### PeripheryBus_1 subsystem_cbus  DigitalTop.sv

![](image-20241031112132982.png)

### CoherenceManagerWrapper subsystem_l2_wrapper DigitalTop.sv

![](image-20241031013341985.png)

#### InclusiveCache l2  CoherenceManagerWrapper.sv

![](image-20241031112634641.png)

![](image-20241031113153384.png)

#### TLCacheCork cork  **CoherenceManagerWrapper.sv**

![image-20241031113807118](image-20241031113807118.png)

![](image-20241031113912098.png)

#### BankBinder binder CoherenceManagerWrapper.sv

![](image-20241031113951757.png)

### CoherenceManagerWrapper subsystem_l2_wrapper  DigitalTop.sv

![](image-20241031095210458.png)

### memorybus subsystem_mbus DigitalTop.sv

![](image-20241031095313158.png)



![](image-20241030204624185.png)

###  DigitalTop system chiptop.sv

![](image-20241030204011379.png)

### Dram

略

![image-20241031120949472](image-20241031120949472.png)

