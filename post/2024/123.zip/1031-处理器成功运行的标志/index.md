---

title: "处理器成功运行的标志"
slug: "处理器成功运行的标志"
description: 
date: "2024-10-31T13:11:58+08:00"
lastmod: "2024-10-31T13:11:58+08:00"
image: 
math: 
license: 
hidden: false
draft: false 
categories: [""]
tags: [""]

---

## 处理器运行

![image-20241031125127267](../1030-big_soc_路径查找/image-20241031125127267.png)

在_success_exit_sim_exit == 1时io_success为1

![image-20241031125156158](../1030-big_soc_路径查找/image-20241031125156158.png)



![](../1030-big_soc_路径查找/image-20241031125250090.png)

```verilog
input         clock,
input         reset,
input         tsi_out_valid,
output        tsi_out_ready,
input  [31:0] tsi_out_bits,

output        tsi_in_valid,
input         tsi_in_ready,
output [31:0] tsi_in_bits,
output [31:0] exit
```

![](image-20241031132938852.png)

![](image-20241031135417464.png)

### SerialRAM ram TestHarness.sv

![](image-20241031140339626.png)

####  TSIToTileLink tsi2tl SerialRAM.sv![](image-20241031135520906.png)

### ChipTop chiptop0 TestHarness.sv ![image-20241031140507499](image-20241031140507499.png)

### DigitalTop system ChipTop.sv

![image-20241031140808505](image-20241031140808505.png)

### AsyncQueue subsystem_fbus_out_async 

![image-20241031140930605](image-20241031140930605.png)

![image-20241031141017157](image-20241031141017157.png)

![](image-20241031141152232.png)

###  TLSerdesser subsystem_fbus_serdesser DigitalTop.sv

![](image-20241031141312322.png)

After the transaction is converted to TileLink, the `TLSerdesser` (located in `generators/testchipip`) serializes the transaction and sends it to the chip (this `TLSerdesser` is sometimes also referred to as a digital serial-link or SerDes). 

### 

\_sbusystem\_fbus\_serdess\_auto\_client\_out_

_subsystem_sbus_auto_coupler_from_bus_named_subsystem_fbus_bus_xing_in_d_bits_opcode

...

后面应该就到core了吧

![](image-20241031142422181.png)


